package lk.sjp.bis.project.business.Custom;

import lk.sjp.bis.project.Entity.User;
import lk.sjp.bis.project.business.SuperBo;

import java.util.List;

public interface ManageUserBO extends SuperBo {

    public void createUser(User user);
    public void updateUser(User user);
    public void deleteUser(String id);
    public User findUser(String id);
    public List<User> getAllUser();

}
