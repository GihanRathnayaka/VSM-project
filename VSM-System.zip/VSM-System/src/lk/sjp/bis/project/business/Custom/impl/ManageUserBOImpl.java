package lk.sjp.bis.project.business.Custom.impl;

import lk.sjp.bis.project.Entity.User;
import lk.sjp.bis.project.business.Custom.ManageUserBO;
import lk.sjp.bis.project.dao.custom.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class ManageUserBOImpl implements ManageUserBO {

   private UserDAO userDAO;

   @Autowired
    public ManageUserBOImpl(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    @Override
    public void createUser(User user) {
        userDAO.save(user);
    }

    @Override
    public void updateUser(User user) {
        userDAO.update(user);
    }

    @Override
    public void deleteUser(String id) {
        userDAO.delete(id);
    }

    @Override
    public User findUser(String id) {
       return userDAO.find(id).get();
    }

    @Override
    public List<User> getAllUser() {
        return userDAO.findAll().get();
    }
}
