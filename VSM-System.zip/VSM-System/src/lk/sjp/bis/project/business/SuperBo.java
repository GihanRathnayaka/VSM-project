package lk.sjp.bis.project.business;

public interface SuperBo {
}
