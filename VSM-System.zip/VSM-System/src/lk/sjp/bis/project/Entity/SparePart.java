package lk.sjp.bis.project.Entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
public class SparePart {
    @Id
    private String sPartId;
    private String name;
    private Date date;
    private String rackNumber;
    private String binCode;
    private double selingPrice;
    private String description;
    @Enumerated
    private IsDeleted isDeleted;
    @ManyToOne
    @JoinColumn(name = "catId", referencedColumnName = "catId")
    private SpareCategory catId;

    @ManyToMany
    @JoinTable(
            name = "VehicleModel_SparePart",
            joinColumns = {@JoinColumn(name = "sPartId", referencedColumnName = "sPartId")}, //own end
            inverseJoinColumns = {@JoinColumn(name = "modelId", referencedColumnName = "modelId")}) //envers end
    private List<VehicleModel> vehicleModels = new ArrayList<>();


    public SparePart() {
    }

    public SparePart(String sPartId, String name, Date date, String rackNumber, String binCode, double selingPrice, String description, IsDeleted isDeleted, SpareCategory catId) {
        this.setsPartId(sPartId);
        this.setName(name);
        this.setDate(date);
        this.setRackNumber(rackNumber);
        this.setBinCode(binCode);
        this.setSelingPrice(selingPrice);
        this.setDescription(description);
        this.setIsDeleted(isDeleted);
        this.setCatId(catId);
    }



    public String getsPartId() {
        return sPartId;
    }

    public void setsPartId(String sPartId) {
        this.sPartId = sPartId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getRackNumber() {
        return rackNumber;
    }

    public void setRackNumber(String rackNumber) {
        this.rackNumber = rackNumber;
    }

    public String getBinCode() {
        return binCode;
    }

    public void setBinCode(String binCode) {
        this.binCode = binCode;
    }

    public double getSelingPrice() {
        return selingPrice;
    }

    public void setSelingPrice(double selingPrice) {
        this.selingPrice = selingPrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public IsDeleted getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(IsDeleted isDeleted) {
        this.isDeleted = isDeleted;
    }

    public SpareCategory getCatId() {
        return catId;
    }

    public void setCatId(SpareCategory catId) {
        this.catId = catId;
    }

    public List<VehicleModel> getVehicleModels() {
        return vehicleModels;
    }

    public void setVehicleModels(List<VehicleModel> vehicleModels) {
        this.vehicleModels = vehicleModels;
    }

    @Override
    public String toString() {
        return "SparePart{" +
                "sPartId='" + sPartId + '\'' +
                ", name='" + name + '\'' +
                ", date=" + date +
                ", rackNumber='" + rackNumber + '\'' +
                ", binCode='" + binCode + '\'' +
                ", selingPrice=" + selingPrice +
                ", description='" + description + '\'' +
                ", isDeleted=" + isDeleted +
                ", catId=" + catId +
                '}';
    }


}
