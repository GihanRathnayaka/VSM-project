package lk.sjp.bis.project.Entity;


public enum IsDeleted {
    NO,YES
}
