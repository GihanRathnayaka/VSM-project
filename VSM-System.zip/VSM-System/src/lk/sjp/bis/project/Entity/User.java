package lk.sjp.bis.project.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "Users")
public class User {
    @Id
    private String userName;
//    @Column(nullable = false, length = 50,unique =true)
    private String password;
    private String name;
    private String userType;
    private String isDelete;

    public User() {
    }

    public User(String userName, String password, String name, String userType, String isDelete) {
        this.userName = userName;
        this.password = password;
        this.name = name;
        this.userType = userType;
        this.isDelete = isDelete;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }


    public String getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(String isDelete) {
        this.isDelete = isDelete;
    }
}
