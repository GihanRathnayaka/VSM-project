package lk.sjp.bis.project.Entity;

import javax.persistence.*;
import java.util.Date;


@Entity
public class Customer {
    @Id
    private String cusId;
    @Column(length = 50,nullable = false)
    private String name;
    private String nic;
    private String address;
    private String address2;
    private String mobile;
    private String city;
    private String description ;
    @Temporal(TemporalType.DATE)
    private Date regDate;
    private String isDeleted;

    public Customer() {
    }

    public Customer(String cusId, String name, String nic, String address, String address2, String mobile, String city, String description, Date regDate, String isDeleted) {
        this.setCusId(cusId);
        this.setName(name);
        this.setNic(nic);
        this.setAddress(address);
        this.setAddress2(address2);
        this.setMobile(mobile);
        this.setCity(city);
        this.setDescription(description);
        this.setRegDate(regDate);
        this.setIsDeleted(isDeleted);
    }


    public String getCusId() {
        return cusId;
    }

    public void setCusId(String cusId) {
        this.cusId = cusId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "cusId='" + cusId + '\'' +
                ", name='" + name + '\'' +
                ", nic='" + nic + '\'' +
                ", address='" + address + '\'' +
                ", address2='" + address2 + '\'' +
                ", mobile='" + mobile + '\'' +
                ", city='" + city + '\'' +
                ", description='" + description + '\'' +
                ", regDate=" + regDate +
                ", isDeleted='" + isDeleted + '\'' +
                '}';
    }
}
