package lk.sjp.bis.project.Entity;

public class Service {
}
