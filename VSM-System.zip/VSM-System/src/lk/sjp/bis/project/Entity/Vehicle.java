package lk.sjp.bis.project.Entity;

import org.joda.time.LocalDate;

import javax.persistence.*;
import java.util.Date;


@Entity
public class Vehicle {

    @Id
    private
    String vRegNo;
    private String chassnum;
    private String color;
    private String description;
    @Temporal(TemporalType.DATE)
    private Date regDate;
    @Enumerated(EnumType.STRING)
    private IsDeleted isDeleted;
    @ManyToOne
    @JoinColumn(name = "customerId",referencedColumnName = "cusId")
    private Customer customerId;
    @ManyToOne
    @JoinColumn(name = "modelId",referencedColumnName = "modelId")
    private VehicleModel modelId ;

    public Vehicle() {
    }

    public Vehicle(String vRegNo, String chassnum, String color, String description, Date regDate, IsDeleted isDeleted, Customer customerId, VehicleModel modelId) {
        this.setvRegNo(vRegNo);
        this.setChassnum(chassnum);
        this.setColor(color);
        this.setDescription(description);
        this.setRegDate(regDate);
        this.setIsDeleted(isDeleted);
        this.setCustomerId(customerId);
        this.setModelId(modelId);
    }


    public String getvRegNo() {
        return vRegNo;
    }

    public void setvRegNo(String vRegNo) {
        this.vRegNo = vRegNo;
    }

    public String getChassnum() {
        return chassnum;
    }

    public void setChassnum(String chassnum) {
        this.chassnum = chassnum;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public IsDeleted getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(IsDeleted isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Customer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Customer customerId) {
        this.customerId = customerId;
    }

    public VehicleModel getModelId() {
        return modelId;
    }

    public void setModelId(VehicleModel modelId) {
        this.modelId = modelId;
    }

    @Override
    public String toString() {
        return "Vehicle{" +
                "vRegNo='" + vRegNo + '\'' +
                ", chassnum='" + chassnum + '\'' +
                ", color='" + color + '\'' +
                ", description='" + description + '\'' +
                ", regDate=" + regDate +
                ", isDeleted=" + isDeleted +
                ", customerId=" + customerId +
                ", modelId=" + modelId +
                '}';
    }
}
