package lk.sjp.bis.project.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SpareCategory {
    @Id
    private
    String catId;
    private String CatName;

    public SpareCategory() {
    }

    public SpareCategory(String catId, String catName) {
        this.setCatId(catId);
        setCatName(catName);
    }


    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }

    public String getCatName() {
        return CatName;
    }

    public void setCatName(String catName) {
        CatName = catName;
    }

    @Override
    public String toString() {
        return "SpareCategory{" +
                "catId='" + catId + '\'' +
                ", CatName='" + CatName + '\'' +
                '}';
    }
}
