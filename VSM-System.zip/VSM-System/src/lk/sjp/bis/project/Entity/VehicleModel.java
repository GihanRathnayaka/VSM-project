package lk.sjp.bis.project.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class VehicleModel {

    @Id
    private
    String modelId;
    private String modelName;
    private String Description;

    public VehicleModel() {
    }

    public VehicleModel(String modelId, String modelName, String description) {
        this.setModelId(modelId);
        this.setModelName(modelName);
        setDescription(description);
    }


    public String getModelId() {
        return modelId;
    }

    public void setModelId(String modelId) {
        this.modelId = modelId;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    @Override
    public String toString() {
        return "VehicleModel{" +
                "modelId='" + modelId + '\'' +
                ", modelName='" + modelName + '\'' +
                ", Description='" + Description + '\'' +
                '}';
    }
}
