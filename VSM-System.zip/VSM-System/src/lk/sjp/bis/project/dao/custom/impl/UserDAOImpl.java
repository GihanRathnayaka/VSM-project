package lk.sjp.bis.project.dao.custom.impl;

import lk.sjp.bis.project.Entity.User;
import lk.sjp.bis.project.dao.custom.UserDAO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.Optional;

@Repository
public class UserDAOImpl implements UserDAO {
    @PersistenceContext
    private EntityManager em;
    @Override
    public Optional<User> find(String s)  {
        return Optional.ofNullable(em.find(User.class,s));
    }

    @Override
    public Optional<List<User>> findAll()  {
//        List<User> select_alias_from_users_alias = em.createQuery("SELECT alias FROM Users alias", User.class).getResultList();
        return Optional.ofNullable(em.createQuery("SELECT alias FROM Users alias",User.class).getResultList());
    }

    @Override
    public void save(User entity) {
        em.persist(entity);

    }

    @Override
    public void update(User entity) {
        em.merge(entity);

    }

    @Override
    public void delete(String s) {
        em.remove(em.getReference(User.class,s));
    }

    @Override
    public void setEntityManager(EntityManager em) {
        this.em=em;

    }
}
