package lk.sjp.bis.project.dao;

import javax.persistence.EntityManager;

public interface SuperDAO {

    void setEntityManager(EntityManager em);
}
