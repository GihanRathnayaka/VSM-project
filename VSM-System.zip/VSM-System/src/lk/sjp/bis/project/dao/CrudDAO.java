package lk.sjp.bis.project.dao;

import lk.sjp.bis.project.dao.SuperDAO;

import java.util.List;
import java.util.Optional;

public interface CrudDAO<T,Key>  extends SuperDAO {

    Optional<T> find(Key key) ;

    Optional<List<T>> findAll() ;

    void save(T entity) ;

    void update(T entity);

    void delete(Key key) ;


}
