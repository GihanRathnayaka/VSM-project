package lk.sjp.bis.project.dao.custom;

import lk.sjp.bis.project.Entity.User;
import lk.sjp.bis.project.dao.CrudDAO;

public interface UserDAO extends CrudDAO<User,String> {
}
