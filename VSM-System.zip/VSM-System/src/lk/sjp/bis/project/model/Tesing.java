package lk.sjp.bis.project.model;

import lk.sjp.bis.project.Entity.User;
import lk.sjp.bis.project.business.Custom.ManageUserBO;
import lk.sjp.bis.project.main.AppInitializer;

import java.util.List;

public class Tesing {



    public static void main(String[] args) {
        //ManageUserBO  manageUserBO =AppInitializer.ctx.getBean(ManageUserBO.class);
      //  List<User> allUser = manageUserBO.getAllUser();
      //  System.out.println(allUser);
    }
}
