package lk.sjp.bis.project.controler;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

public class HomeControler {
    @FXML
    private ImageView imgBack;
    public ImageView imgCustomer;
    public ImageView imgBike;
    public ImageView imgInquiry;
    @FXML
    private  Button btnSettings;

    public void imgBack_OnMouseClick(MouseEvent mouseEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/lk/emo/service/view/Login.fxml"));
        Scene scene =new Scene(root);
        Stage prmary = (Stage) imgBack.getScene().getWindow();
        prmary.setScene(scene);
        prmary.show();
        prmary.centerOnScreen();
    }



    public void imgCustomer_OnMouseClick(MouseEvent mouseEvent)throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("/lk/emo/service/view/Customer.fxml"));
        Scene scene =new Scene(root);
        Stage prmary = (Stage) imgCustomer.getScene().getWindow();
        prmary.setScene(scene);
        prmary.show();
        prmary.centerOnScreen();
    }

    public void imgBick_OnMouseClick(MouseEvent mouseEvent)throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("/lk/emo/service/view/Vehicle.fxml"));
        Scene scene =new Scene(root);
        Stage prmary = (Stage) imgBike.getScene().getWindow();
        prmary.setScene(scene);
        prmary.show();
        prmary.centerOnScreen();
    }

    public void imgInquiry_OnMouseClick(MouseEvent mouseEvent)throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("/lk/emo/service/view/Inquiry.fxml"));
        Scene scene =new Scene(root);
        Stage prmary = (Stage) imgInquiry.getScene().getWindow();
        prmary.setScene(scene);
        prmary.show();
        prmary.centerOnScreen();
    }

    public void imgInquiry_OnMouseClicked(MouseEvent mouseEvent) {
    }

    @FXML
    private  void btnSettings_OnAction(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/lk/sjp/bis/project/view/UserCreate.fxml"));
        Scene scene =new Scene(root);
        Stage prmary = (Stage) imgInquiry.getScene().getWindow();
        prmary.setScene(scene);
        prmary.show();
        prmary.centerOnScreen();
    }
}
