package lk.sjp.bis.project.controler;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import lk.sjp.bis.project.Entity.User;
import lk.sjp.bis.project.bo.LoginServicesBO;
import lk.sjp.bis.project.bo.impl.LoginServicesBOImpl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginControler {

    @FXML
    private JFXTextField txtUserName;

    @FXML
    private  JFXPasswordField txtPw;

    @FXML
    private  JFXButton tbnLogin;

    @FXML
    private  ImageView img_Exit;


    @FXML
    private  void txtUserName_OnAction(ActionEvent actionEvent) {
        txtPw.requestFocus();
    }


    @FXML
    private  void txtPw_OnAction(ActionEvent actionEvent) {

        tbnLogin.getOnAction();

    }



    @FXML
    private  void tbnLogin_OnAction(ActionEvent actionEvent) throws IOException {
//        //When click the login button and User name field is empty
//        if(txtUserName.getText().trim().isEmpty()){
//            new Alert(Alert.AlertType.ERROR,"User Name Is Empty !", ButtonType.OK).showAndWait();
//            txtUserName.requestFocus();
//            return;
//        }
//        //When click the login button and password field is empty
//        if(txtPw.getText().trim().isEmpty()){
//            new Alert(Alert.AlertType.ERROR,"Enter Your Password !", ButtonType.OK).showAndWait();
//            txtPw.requestFocus();
//            return;
//        }
//
//        //User is null
//        User user = null;
//        if(null==user){
//            new Alert(Alert.AlertType.ERROR,"Please Check Your User Name Password !", ButtonType.OK).showAndWait();
//            txtUserName.requestFocus();
//            return;
//        }
//
//        if(user.getPassword().equals(txtPw.getText().trim())){
////            new Alert(Alert.AlertType.CONFIRMATION,"Wade Goda!", ButtonType.OK).showAndWait();
//
//            Parent root = FXMLLoader.load(getClass().getResource("/lk/emo/service/view/Home.fxml"));
//            Scene scene =new Scene(root);
//            Stage prmary = (Stage) tbnLogin.getScene().getWindow();
//            prmary.setScene(scene);
//            prmary.show();
//            prmary.centerOnScreen();
//
//        //Wrong username and password
//       }else {
//            new Alert(Alert.AlertType.ERROR,"Please Check Your User Name Password !", ButtonType.OK).showAndWait();
//            txtUserName.requestFocus();
//            return;
//        }


        Parent root = FXMLLoader.load(getClass().getResource("/lk/sjp/bis/project/view/Home.fxml"));
        Scene scene =new Scene(root);
        Stage prmary = (Stage) tbnLogin.getScene().getWindow();
        prmary.setScene(scene);
        prmary.show();
        prmary.centerOnScreen();


    }


    @FXML
    private  void img_Exit_OnMouseClicked(MouseEvent mouseEvent) {
        System.exit(0);
    }
}
