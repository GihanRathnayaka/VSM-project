package lk.sjp.bis.project.controler;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.sjp.bis.project.Entity.User;
import lk.sjp.bis.project.business.Custom.ManageUserBO;
import lk.sjp.bis.project.business.Custom.impl.ManageUserBOImpl;
import lk.sjp.bis.project.main.AppInitializer;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class UserCreateControler<T> {
    public JFXTextField txtName;
    public JFXTextField txtuseName;
    public RadioButton rbIsDeted;
    public JFXPasswordField txtPassword;
    public JFXPasswordField txtCP;
    public JFXComboBox cmbUserType;
    public TableView<User> tblUser;
    public JFXButton btnSave;
    public JFXButton tnUpdate;
    public JFXButton btnDelete;


    private ManageUserBO manageUserBO = AppInitializer.ctx.getBean(ManageUserBO.class);

    public void initialize() {
        ArrayList<String> list = new ArrayList<>();
        list.add("SuperUser");
        list.add("Admin");
        cmbUserType.setItems(FXCollections.observableArrayList(list));
        laodAllUsers();
        tblUser.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("name"));
        tblUser.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("userName"));
        tblUser.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("userType"));
        tblUser.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("password"));
        tblUser.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("isDelete"));

        tblUser.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<User>() {
            @Override
            public void changed(ObservableValue<? extends User> observable, User oldValue, User user) {
                if (user == null) {
                    return;
                }


                txtCP.setText(user.getPassword());
                txtPassword.setText(user.getPassword());
                txtName.setText(user.getName());
                txtuseName.setText(user.getUserName());
                cmbUserType.getItems().forEach(o -> {
                    if (user.getUserType().equals(o.toString())) {
                        cmbUserType.setPromptText(user.getUserType());
                    }
                });
                if (user.getIsDelete().equals("Y")) {
                    rbIsDeted.setSelected(true);
                } else {
                    rbIsDeted.setSelected(false);
                }

            }
        });


    }

    public void btnSave_OnAction(ActionEvent actionEvent) {

        if (txtName.getText().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter FullName Name", ButtonType.OK).showAndWait();
            txtName.requestFocus();
            return;
        }
        if (txtuseName.getText().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter UserUser Name", ButtonType.OK).showAndWait();
            txtuseName.requestFocus();
            return;
        }
        if (cmbUserType.getSelectionModel().getSelectedItem().toString().trim().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter Select UserType !", ButtonType.OK).showAndWait();
            cmbUserType.requestFocus();
            return;
        }

        if (txtPassword.getText().trim().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter Password !", ButtonType.OK).showAndWait();
            txtPassword.requestFocus();
            return;
        }

        if (txtCP.getText().trim().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter Comfirm Password !", ButtonType.OK).showAndWait();
            txtCP.requestFocus();
            return;
        }

        String confirmPW = txtCP.getText();
        String pw = txtPassword.getText();
        String name = txtName.getText();
        String userName = txtuseName.getText();
        boolean selected = rbIsDeted.isSelected();

        String userType = cmbUserType.getSelectionModel().getSelectedItem().toString().trim();
        String isDeteted = "N";
        if (!selected) {
            isDeteted = "Y";
        }
        if (!confirmPW.trim().equals(pw.trim())) {
            new Alert(Alert.AlertType.ERROR, "Password Not Match !", ButtonType.OK).showAndWait();
            txtCP.requestFocus();
            return;
        }

        User user = new User(userName, pw, name, userType, isDeteted);
        try {

            manageUserBO.createUser(user);
            new Alert(Alert.AlertType.INFORMATION, "Successfuly User Created !", ButtonType.OK).showAndWait();

        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "There is a Error !", ButtonType.OK).showAndWait();
            e.getStackTrace();
        }


        txtCP.clear();
        txtPassword.clear();
        txtuseName.clear();
        txtName.clear();
        rbIsDeted.setSelected(false);
        cmbUserType.getSelectionModel().clearSelection();
        txtPassword.clear();
        laodAllUsers();

    }

    public void tnUpdate_OnAction(ActionEvent actionEvent) {

        if (txtName.getText().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter FullName Name", ButtonType.OK).showAndWait();
            txtName.requestFocus();
            return;
        }
        if (txtuseName.getText().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter UserUser Name", ButtonType.OK).showAndWait();
            txtuseName.requestFocus();
            return;
        }
        if (cmbUserType.getSelectionModel().getSelectedItem().toString().trim().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter Select UserType !", ButtonType.OK).showAndWait();
            cmbUserType.requestFocus();
            return;
        }

        if (txtPassword.getText().trim().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter Password !", ButtonType.OK).showAndWait();
            txtPassword.requestFocus();
            return;
        }

        if (txtCP.getText().trim().isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Please Enter Comfirm Password !", ButtonType.OK).showAndWait();
            txtCP.requestFocus();
            return;
        }

        String confirmPW = txtCP.getText();
        String pw = txtPassword.getText();
        String name = txtName.getText();
        String userName = txtuseName.getText();
        boolean selected = rbIsDeted.isSelected();

        String userType = cmbUserType.getSelectionModel().getSelectedItem().toString().trim();
        String isDeteted = "N";
        if (!selected) {
            isDeteted = "Y";
        }
        if (!confirmPW.trim().equals(pw.trim())) {
            new Alert(Alert.AlertType.ERROR, "Password Not Match !", ButtonType.OK).showAndWait();
            txtCP.requestFocus();
            return;
        }

        User user = new User(userName, pw, name, userType, isDeteted);
        try {

            manageUserBO.updateUser(user);
            new Alert(Alert.AlertType.INFORMATION, "Successfuly User Updated !", ButtonType.OK).showAndWait();

        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "There is a Error !", ButtonType.OK).showAndWait();
            e.getStackTrace();
        }


        txtCP.clear();
        txtPassword.clear();
        txtuseName.clear();
        txtName.clear();
        rbIsDeted.setSelected(false);
        cmbUserType.getSelectionModel().clearSelection();
        txtPassword.clear();
        laodAllUsers();


    }

    public void btnDelete_OnAction(ActionEvent actionEvent) {

        try {

            manageUserBO.deleteUser(txtuseName.getText().trim());
            new Alert(Alert.AlertType.INFORMATION, "Successfuly User Deleted !", ButtonType.OK).showAndWait();

        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "There is a Error !", ButtonType.OK).showAndWait();
            e.getStackTrace();
        }
        txtCP.clear();
        txtPassword.clear();
        txtuseName.clear();
        txtName.clear();
        rbIsDeted.setSelected(false);
        cmbUserType.getSelectionModel().clearSelection();
        txtPassword.clear();
        laodAllUsers();
    }

    private void laodAllUsers() {

        List<User> allUser = null;
        try {
            allUser = manageUserBO.getAllUser();
        } catch (Exception e) {
            e.getStackTrace();
        }
        if (allUser == null) {
            return;
        }
        ObservableList<User> users = FXCollections.observableArrayList(allUser);
        tblUser.setItems(users);

    }


}
